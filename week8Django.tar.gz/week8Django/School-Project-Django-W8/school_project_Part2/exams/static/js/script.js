let button = document.getElementById('mybutton')

button.addEventListener('click', function(){
    alert("You clicked me!")
})
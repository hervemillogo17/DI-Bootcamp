from django.apps import AppConfig


class ExamsConfig(AppConfig):
    name = 'exams'
